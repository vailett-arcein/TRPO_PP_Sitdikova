﻿using PP1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PP1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string captchaText = "";
        int failcaptcha = 0, secondsBlock = 20, id_userblock;
        DispatcherTimer timerBlock = new DispatcherTimer();
        DispatcherTimer time = new DispatcherTimer();
        Entities.TRPO_pp1Entities10 Bd;
        
        public MainWindow()
        {
            InitializeComponent();
            time.Interval = TimeSpan.FromSeconds(1);
            time.Tick += tim_tick;
            Bd = new Entities.TRPO_pp1Entities10();
        }
        int fail = 0;
        //просмотр пароля
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PasswordBX.Visibility = Visibility.Hidden;
            passwordBX.Visibility = Visibility.Visible;
            passwordBX.Text = PasswordBX.Password;
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            passwordBX.Visibility = Visibility.Hidden;
            PasswordBX.Visibility = Visibility.Visible;
            PasswordBX.Password = passwordBX.Text;
        }
        int Countproblems = 0;
        int clock = 10;
        DispatcherTimer timer = new DispatcherTimer();
        //авторизация
        private void enter_Click(object sender, RoutedEventArgs e)
        {
            if (loginBX.Text != string.Empty && (passwordBX.Text != string.Empty || PasswordBX.Password != string.Empty))
            {
                if (Bd.Employees.Any(x => x.lodin == loginBX.Text))
                {
                    if (Bd.Employees.Any(x => x.lodin == loginBX.Text && (passwordBX.Text == x.password || PasswordBX.Password == x.password)))
                    {
                        DateTime now = DateTime.Now;
                        DateTime dateWithoutMilliseconds = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second);
                        var polsovatel = App.ppNewEntities.Employees.FirstOrDefault(BDlogpass => BDlogpass.lodin == loginBX.Text 
                        && (BDlogpass.password == PasswordBX.Password || BDlogpass.password == passwordBX.Text));
                        if (polsovatel != null)
                        {
                            switch (polsovatel.EmployeeID)
                            {
                                case 1:
                                    admin admin0 = new admin();
                                    admin0.Show();
                                    this.Close();
                                    break;
                                case 2:
                                    Order Order0 = new Order();
                                    Order0.Show();

                                    this.Close();
                                    break;
                                case 3:
                                    Order order0 = new Order();
                                    order0.Show();
                                    this.Close();
                                    break;
                            }
                        }
                        else
                        {
                            Countproblems++;
                            Proverka();
                        }
                    }
                    else
                    {
                        fail++;
                        if (fail == 3)
                        {
                            Avtorizazia.Visibility = Visibility.Hidden;
                            captcha.Visibility = Visibility.Visible;
                            time.Stop();
                            generatorcaptcha();
                            fail = 0;
                            var id_staff = Bd.Employees.Where(x => x.lodin == loginBX.Text).FirstOrDefault();
                            Bd.SaveChanges();
                        }
                        else MessageBox.Show("Неверный пароль");
                    }
                }
                else
                {
                    MessageBox.Show("Неверный логин");
                }
            }
            else MessageBox.Show("Введите данные");
        }
        int not = 10;
        System.Windows.Threading.DispatcherTimer timer2 = new System.Windows.Threading.DispatcherTimer();

        public void Proverka()
        {
            if (Countproblems <5)
            {
                MessageBox.Show("Не все поля заполнены");
            }
            if (Countproblems == 2)
            {
                captcha capcha = new captcha();
                capcha.ShowDialog();
            }
            //таймер блокировки
            if (Countproblems >= 5)
            {
                timer.Tick += new EventHandler(timertick);
                timer.Interval = new TimeSpan(0, 0, 1);
                timer.Start();
                if (clock != 0)
                {
                    this.IsEnabled = false;
                    MessageBox.Show(String.Format("Вы заблокированы на 10 секунд", clock));
                }
            }
        }

        private void timertick(object sender, EventArgs e)
        {
            if (clock == 0)
            {
                this.IsEnabled = true; ;
                MessageBox.Show("Вход в систему возобновлен, повторите попытку!");
                timer.Stop();
                clock = 10;
            }
            else
            {
                clock--;
            }
        }
        //обновление капчи
        private void Obnovit(object sender, RoutedEventArgs e)
        {
            generatorcaptcha();
        }
        //генератор капчи
        public void generatorcaptcha()
        {
            canva.Children.Clear();
            Random rnd = new Random();
            RotateTransform rotateTransform = new RotateTransform();
            TextBlock textBlock = new TextBlock();
            string captchasim = "qwertyuiopasdfghjklzxcvbnm1234567890";
            captchaText = "";
            rotateTransform.Angle = rnd.Next(-20, 20);
            for (int i = 0; i < 4; i++)
            {
                char generat = captchasim[rnd.Next(captchasim.Length)];
                captchaText += generat;

            }
            rotateTransform.Angle = rnd.Next(-20, 20);
            textBlock.Text = captchaText;
            textBlock.FontSize = 32;
            textBlock.RenderTransform = rotateTransform;
            Canvas.SetLeft(textBlock, rnd.Next(20, 100));
            Canvas.SetTop(textBlock, rnd.Next(20, 30));
            canva.Children.Add(textBlock);
            for (int i = 0; i < 600; i++)
            {

                Ellipse ellipse = new Ellipse();
                int r = rnd.Next(3, 5);
                ellipse.Height = r; ellipse.Width = r;
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                ellipse.Fill = brus;
                Canvas.SetLeft(ellipse, rnd.Next(250));
                Canvas.SetTop(ellipse, rnd.Next(100));

                canva.Children.Add(ellipse);
            }
            for (int i = 0; i < 2; i++)
            {
                Line line = new Line();
                line.X1 = rnd.Next(0, 50);
                line.Y1 = rnd.Next(0, 50);
                line.X2 = rnd.Next(150, 250);
                line.Y2 = rnd.Next(51, 100);
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                line.Stroke = brus;
                line.StrokeThickness = 3;
                canva.Children.Add(line);

            }

        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (textcaptcha.Text != String.Empty)
            {
                if (textcaptcha.Text.ToLower() == captchaText)
                {
                    textcaptcha.Text = string.Empty;
                    loginBX.Text = string.Empty;
                    passwordBX.Text = string.Empty;
                    PasswordBX.Password = string.Empty;
                    Avtorizazia.Visibility = Visibility.Visible;
                    captcha.Visibility = Visibility.Hidden;
                }
                else
                {
                    failcaptcha++;
                    generatorcaptcha();
                    if (failcaptcha > 2)
                    {
                        captcha.Visibility = Visibility.Hidden;
                        Avtorizazia.Visibility = Visibility.Visible;
                        enter.IsEnabled = false;
                        textcaptcha.Text = string.Empty;
                        loginBX.Text = string.Empty;
                        passwordBX.Text = string.Empty;
                        PasswordBX.Password = string.Empty;
                        failcaptcha = 0;
                        sec = 10;
                        time.Start();
                    }
                    else MessageBox.Show("Неверная каптча");
                }
            }
            else MessageBox.Show("Введите каптчу");

        }
        int sec = 10;
        public void tim_tick(object sender, EventArgs e)
        {
            Time.Text = "Система заблокирована. Осталось " + sec.ToString() + " секунд";
            if (sec == 0)
            {
                Time.Text = string.Empty;
                enter.IsEnabled = true;
                time.Stop();
            }
            sec--;

        }
        public void timerBlock_tick(object sender, EventArgs e)
        {
            if (secondsBlock == 0)
            {
                timerBlock.Stop();
            }
            secondsBlock--;
        }

    }
}


