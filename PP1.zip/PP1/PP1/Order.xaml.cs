﻿using PP1.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace PP1
{
    /// <summary>
    /// Логика взаимодействия для Order.xaml
    /// </summary>
    public partial class Order : Window
    {
        Entities.TRPO_pp1Entities10 Bd;
        DispatcherTimer timer = new DispatcherTimer();
        int timeLeft = 600; // Установите начальное время в 10 минуты (600 секунд)
        public Order()
        {
            Bd = new Entities.TRPO_pp1Entities10();
            InitializeComponent();
            clientBtn_Click(null, null);
            // Установка интервала таймера в 1 секунду
            timer.Interval = TimeSpan.FromSeconds(1);
            // Добавление обработчиков событий для движения мыши и нажатия клавиш
            this.MouseMove += MainWindow_MouseMove;
            this.KeyDown += MainWindow_KeyDown;
            // Добавление обработчика события для таймера
            timer.Tick += Timer_Tick;
            // Запуск таймера
            timer.Start();
        }
        private void MainWindow_MouseMove(object sender, MouseEventArgs e)
        {
            // Сбросьте таймер и время при движении мыши
            timer.Stop();
            timeLeft = 600;
            timer.Start();
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            // Сбросьте таймер и время при нажатии клавиши
            timer.Stop();
            timeLeft = 600;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timeLeft--;

            // Обновите отображение оставшегося времени
            TimerBlocking.Text = "Таймер: " + TimeSpan.FromSeconds(timeLeft).ToString(@"mm\:ss");
            if (timeLeft == 300)
            {
                timer.Stop();
                timeLeft = 300; timer.Start();
                MessageBox.Show("Таймер", "До закрытия окна осталось пять минут");
                // Покажите предупреждение, когда остается одна минута

            }
            else if (timeLeft <= 0)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
                // Ваш код для блокировки входа здесь
                timer.Stop(); // Остановите таймер
            }
        }
        public void hidden()
        {
            clientLV.Visibility = Visibility.Hidden;
            clientGr.Visibility = Visibility.Hidden;
            servicesGr.Visibility = Visibility.Hidden;
            servicesLV.Visibility = Visibility.Hidden;
            gridOrders.Visibility = Visibility.Hidden;

        }
        private void addclient_Click(object sender, RoutedEventArgs e)
        {
            addclient addclient = new addclient();
            addclient.Show();
            this.Close();

        }

        private void clientBtn_Click(object sender, RoutedEventArgs e)
        {
            hidden();
            clientLV.Visibility = Visibility.Visible;
            clientGr.Visibility = Visibility.Visible;
            //clientBtn.Background = new SolidColorBrush(Color.FromRgb(118, 227, 131));
            clientLV.ItemsSource = Bd.Client.ToList();
        }

        private void servicesBtn_Click(object sender, RoutedEventArgs e)
        {
            hidden();
            //servicesBtn.Background = new SolidColorBrush(Color.FromRgb(118, 227, 131));
            servicesGr.Visibility = Visibility.Visible;
            servicesLV.Visibility = Visibility.Visible;
            servicesLV.ItemsSource = Bd.Services.ToList();
        }

        private void addservices_Click(object sender, RoutedEventArgs e)
        {
            if (nameservices.Text != string.Empty && costservices.Text != string.Empty)
            {
                Random rnd = new Random();
                string codsim = "qwertyuiopasdfghjklzxcvbnm1234567890";
                string cod = "";
                for (int i = 0; i < 8; i++)
                {
                    char generat = codsim[rnd.Next(codsim.Length)];
                    cod += generat;
                }
                Services services = new Services
                {
                    Name = nameservices.Text,
                    Code = cod,
                    Cost = Convert.ToInt32(costservices.Text),
                };
                Bd.Services.Add(services);
                Bd.SaveChanges();
                servicesLV.ItemsSource = Bd.Services.ToList();
            }
            else
            {
                MessageBox.Show("Не все поля заполнины");
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (poiskclient.Text != string.Empty)
            {
                var cliet = poiskclient.Text;
                var _poisk = Bd.Client.Where(x => x.FirstName.ToLower().StartsWith(cliet.ToLower()) |
                x.Name.ToLower().StartsWith(cliet.ToLower()) | x.LastName.ToLower().StartsWith(cliet.ToLower()));
                clientLV.ItemsSource = _poisk.ToList();
            }
            else
            {
                clientLV.ItemsSource = Bd.Client.ToList();
            }

        }

        private void poiskservices_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (poiskservices.Text != string.Empty)
            {
                var services = poiskservices.Text;
                var _poisk = Bd.Services.Where(x => x.Name.ToLower().StartsWith(poiskservices.Text.ToLower()) |
                x.Code.ToLower().StartsWith(services.ToLower()));
                servicesLV.ItemsSource = _poisk.ToList();
            }
            else
            {
                servicesLV.ItemsSource = Bd.Services.ToList();
            }
        }

        private void costservices_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            costservices.Text = new string(costservices.Text.Where(char.IsDigit).ToArray());
        }

        private void backbtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ordersBtn_Click(object sender, RoutedEventArgs e)
        {
            hidden();
            gridOrders.Visibility = Visibility.Visible;
            ObservableCollection<PP1.Entities.Services> observableServices = new ObservableCollection<PP1.Entities.Services>(Bd.Services);
            ordersServices.ItemsSource = observableServices;
            ordersClient.ItemsSource = Bd.Client.ToList();
            listServices.Items.Clear();
            surnameNameMiddlename.Text = string.Empty;
            timeOrders.Text = string.Empty;
        }

        private void ordersServices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = (Services)ordersServices.SelectedItem;

            if (selectedItem != null)
            {
                ObservableCollection<Services> items = (ObservableCollection<Services>)ordersServices.ItemsSource;
                var id_services = (Services)ordersServices.SelectedItem;
                listServices.Items.Add(selectedItem);
                items.Remove(selectedItem);

            }
        }

        private void listServices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selectedItem = (Services)listServices.SelectedItem;
            if (selectedItem != null)
            {
                ObservableCollection<Services> items = (ObservableCollection<Services>)ordersServices.ItemsSource;
                items.Add(selectedItem); // Добавляем обратно
                listServices.Items.Remove(selectedItem); // Удаляем из listServices

            }
        }

        private void arrangeBtn_Click(object sender, RoutedEventArgs e)
        {
            if (surnameNameMiddlename.Text != string.Empty)
            {
                if (timeOrders.Text != string.Empty)
                {
                    if (listServices.Items.Count != null)
                    {
                        DateTime now = DateTime.Now;
                        DateTime date = new DateTime(now.Year, now.Month, now.Day);
                        TimeSpan time = new TimeSpan(now.Hour, now.Minute, now.Second);
                        Orders orders = new Orders
                        {
                            OrderDate = date,
                            OrderTime = time,
                            ClientID = ((Client)ordersClient.SelectedItem).ClientID,
                            StatusID = 3,
                            OrderEndDate = null,
                            Time_rental = Convert.ToInt32(timeOrders.Text),
                        };
                        var id_orders = Bd.Orders.Add(orders);
                        Bd.SaveChanges();
                        foreach (var item in listServices.Items)
                        {
                            var id_services = (Services)item;
                            services_orders services_Orders = new services_orders
                            {
                                OrderID = id_orders.OrderID,
                                ServicesID = id_services.ServicesID,
                            };
                            Bd.services_orders.Add(services_Orders);
                        }
                        Bd.SaveChanges();
                        MessageBox.Show("Заказ оформлен");
                        ordersBtn_Click(null, null);
                    }
                    else
                    {
                        MessageBox.Show("Выберите услуги");
                    }
                }
                else
                {
                    MessageBox.Show("Введите время проката");
                }
            }
            else
            {
                MessageBox.Show("Выберите клиента");
            }
        }

        private void ordersClient_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            surnameNameMiddlename.Text = ((Client)ordersClient.SelectedItem).FirstName + " "
              + ((Client)ordersClient.SelectedItem).Name + " " + ((Client)ordersClient.SelectedItem).LastName;
        }
    }
}
