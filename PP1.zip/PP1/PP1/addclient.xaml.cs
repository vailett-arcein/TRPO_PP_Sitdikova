﻿using PP1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PP1
{
    /// <summary>
    /// Логика взаимодействия для addclient.xaml
    /// </summary>
    public partial class addclient : Window
    {
        Entities.TRPO_pp1Entities10 Bd;
        public addclient()
        {
            Bd = new Entities.TRPO_pp1Entities10();
            InitializeComponent();
        }
        // Только цифры в тексте
        private void SeriesClient_TextChanged(object sender, TextChangedEventArgs e)
        {

            SeriesClient.Text = new string(SeriesClient.Text.Where(char.IsDigit).ToArray());
        }

        private void CodeClient_TextChanged(object sender, TextChangedEventArgs e)
        {

            CodeClient.Text = new string(CodeClient.Text.Where(char.IsDigit).ToArray());
        }

        private void NumberClient_TextChanged(object sender, TextChangedEventArgs e)
        {

            NumberClient.Text = new string(NumberClient.Text.Where(char.IsDigit).ToArray());
        }

        private void IndexClient_TextChanged(object sender, TextChangedEventArgs e)
        {

            IndexClient.Text = new string(IndexClient.Text.Where(char.IsDigit).ToArray());
        }

        private void SaveAddClient_Click(object sender, RoutedEventArgs e)
        {
            if (SurnameClient.Text != string.Empty &&
                NameClient.Text != string.Empty && MiddlenameClient.Text != string.Empty
                && SeriesClient.Text != string.Empty &&
                NumberClient.Text != string.Empty
                && IndexClient.Text != string.Empty && DateOfBirthClient.Text != string.Empty
                && AddressClient.Text != string.Empty && EmailClient.Text != string.Empty)
            {
                Client client = new Client
                {
                    ClientID = Convert.ToInt32(CodeClient.Text),
                    FirstName = SurnameClient.Text,
                    Name = NameClient.Text,
                    LastName = MiddlenameClient.Text,
                    PassportSeries = Convert.ToInt32(SeriesClient.Text),
                    PassportNumber = Convert.ToInt32(NumberClient.Text),
                    Indexs = Convert.ToInt32(IndexClient.Text),
                    BirthDate = Convert.ToDateTime(DateOfBirthClient.Text),
                    Address = AddressClient.Text,
                    Email = EmailClient.Text,
                };
                Bd.Client.Add(client);
                Bd.SaveChanges();
                backBtn_Click(null, null);
            }
            else
            {
                MessageBox.Show("Заполните все поля");
            }

        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            Order order = new Order();
            order.Show();
            this.Close();
        }
    }
}