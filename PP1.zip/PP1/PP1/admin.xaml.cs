﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PP1
{
    /// <summary>
    /// Логика взаимодействия для admin.xaml
    /// </summary>
    public partial class admin : Window
    {
        Entities.TRPO_pp1Entities10 Bd;
        DispatcherTimer timer = new DispatcherTimer();
        int timeLeft = 600; // Установите начальное время в 10 минуты (600 секунд)
        public admin()
        {
            Bd = new Entities.TRPO_pp1Entities10();
            InitializeComponent();
            employeeBtn_Click(null, null);
            // Установка интервала таймера в 1 секунду
            timer.Interval = TimeSpan.FromSeconds(1);
            // Добавление обработчиков событий для движения мыши и нажатия клавиш
            this.MouseMove += MainWindow_MouseMove;
            this.KeyDown += MainWindow_KeyDown;
            // Добавление обработчика события для таймера
            timer.Tick += Timer_Tick;
            // Запуск таймера
            timer.Start();
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs e)
        {
            // Сбросьте таймер и время при движении мыши
            timer.Stop();
            timeLeft = 600;
            timer.Start();
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            // Сбросьте таймер и время при нажатии клавиши
            timer.Stop();
            timeLeft = 600;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timeLeft--;
            // Обновление отображения оставшегося времени
            TimerBlocking.Text = "Таймер: " + TimeSpan.FromSeconds(timeLeft).ToString(@"mm\:ss");
            if (timeLeft == 300)
            {
                timer.Stop();
                timeLeft = 300; timer.Start();
                MessageBox.Show("Таймер", "До закрытия окна осталось пять минут");
            }
            else if (timeLeft <= 0)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
                timer.Stop();
            }
        }

        private void filtrac_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            employeeLV.ItemsSource = Bd.Employees.Where(x => x.lodin == filtrac.Text).ToList();
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            employeeLV.ItemsSource = Bd.Employees.ToList();
            filtrac.SelectedIndex = -1;
        }

        private void ordersBtn_Click(object sender, RoutedEventArgs e)
        {
            employeeLV.Visibility = Visibility.Hidden;
            filterGr.Visibility = Visibility.Hidden;
            ordersLV.Visibility = Visibility.Visible;
            ordersLV.ItemsSource = Bd.services_orders.AsEnumerable().GroupBy(z => z.Orders).Select(z => new
            {
                Itemsone = $"Клиент {Bd.Client.Where(x => x.ClientID == z.Key.ClientID).FirstOrDefault().FirstName} " +
                $"{Bd.Client.Where(x => x.ClientID == z.Key.ClientID).FirstOrDefault().Name} {Bd.Client.Where(x => x.ClientID == z.Key.ClientID).FirstOrDefault().LastName}",
                Itemstwo = $"Статус: {Bd.Status.Where(x => x.StatusID == z.Key.StatusID).FirstOrDefault().Name} ",
                Itemsthree = $"Время проката {z.Key.Time_rental} мин " +
                $"Услуги: {string.Join(", ", z.Select(c => Bd.Services.FirstOrDefault(v => v.ServicesID == c.ServicesID).Name))}",
                Itemsfour = $"Дата и время создание заказа: {z.Key.OrderDate}",
                Itemsfive = $"Дата закрытии:{z.Key.OrderEndDate}",
            }).ToList();
        }
        private void employeeBtn_Click(object sender, RoutedEventArgs e)
        {
            employeeLV.ItemsSource = Bd.Employees.ToList();
            filtrac.ItemsSource = Bd.Employees.ToList();
            employeeLV.Visibility = Visibility.Visible;
            filterGr.Visibility = Visibility.Visible;
            ordersLV.Visibility = Visibility.Hidden;

        }
    }
}
