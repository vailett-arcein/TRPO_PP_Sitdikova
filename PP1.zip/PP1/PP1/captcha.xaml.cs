﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PP1
{
    /// <summary>
    /// Логика взаимодействия для captcha.xaml
    /// </summary>
    public partial class captcha : Window
    {
        public captcha()
        {
            InitializeComponent();
            GenerateCaptcha();
        }
        int error = 0;
        string captchaText = "";
        int not = 15;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        private void timerTick(object sender, EventArgs e)
        {
            if (not == 0)
            {
                this.IsEnabled = true;
                MessageBox.Show("Можете вводить captcha");
                timer.Stop();
                error = 0;
                not = 15;
            }
            else
            {
                not--;
            }

        }
        private void proverkaButton_Click(object sender, RoutedEventArgs e)
        {
            if (proverkaText.Text == captchaText)
            {
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Не верно");
                error++;
                if (error == 3)
                {
                    this.IsEnabled = false;
                    proverkaText.Clear();
                    MessageBox.Show("Слишком много попыток, подождите", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    timer.Tick += new EventHandler(timerTick);
                    timer.Interval = new TimeSpan(0, 0, 1);
                    timer.Start();
                }

            }
        }
        private void GenerateCaptcha()
        {
            captchaTextBox.Children.Clear();
            Random rnd = new Random();
            RotateTransform rotateTransform = new RotateTransform();
            TextBlock textBlock = new TextBlock();
            string captchasim = "йцукенгшщзхъфывапролджэячсмитьбю1234567890";
            captchaText = "";
            rotateTransform.Angle = rnd.Next(-20, 20);
            for (int i = 0; i < 4; i++)
            {
                char generat = captchasim[rnd.Next(captchasim.Length)];
                captchaText += generat;

            }
            rotateTransform.Angle = rnd.Next(-20, 20);
            textBlock.Text = captchaText;
            textBlock.FontSize = 32;
            textBlock.RenderTransform = rotateTransform;
            Canvas.SetLeft(textBlock, rnd.Next(20, 100));
            Canvas.SetTop(textBlock, rnd.Next(20, 30));
            captchaTextBox.Children.Add(textBlock);
            for (int i = 0; i < 600; i++)
            {

                Ellipse ellipse = new Ellipse();
                int r = rnd.Next(3, 5);
                ellipse.Height = r; ellipse.Width = r;
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                ellipse.Fill = brus;
                Canvas.SetLeft(ellipse, rnd.Next(250));
                Canvas.SetTop(ellipse, rnd.Next(100));

                captchaTextBox.Children.Add(ellipse);
            }
            for (int i = 0; i < 2; i++)
            {
                Line line = new Line();
                line.X1 = rnd.Next(0, 50);
                line.Y1 = rnd.Next(0, 50);
                line.X2 = rnd.Next(150, 250);
                line.Y2 = rnd.Next(51, 100);
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                line.Stroke = brus;
                line.StrokeThickness = 3;
                captchaTextBox.Children.Add(line);
            }
        }
        private void generaits_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }
    }
}


